package br.com.brasilprev.bprextratodmlg.repository.config;

import javax.sql.DataSource;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;

/**
 * The Class DataSourcesConfig.
 */
@Configuration
@EnableConfigurationProperties
public class DataSourcesConfig {
    /**
     * Slave jdbc template.
     * 
     * @return the jdbc template
     */
    @Bean(name = "jdbcPrimary")
    public JdbcTemplate slaveJdbcTemplate() {
        return new JdbcTemplate(primaryDataSource());
    }

    /**
     * Master jdbc template.
     * 
     * @return the jdbc template
     */
    @Bean(name = "jdbcSecondary")
    public JdbcTemplate masterJdbcTemplate() {
        JdbcTemplate j = new JdbcTemplate(secondaryDataSource());
        j.setDataSource(secondaryDataSource());
        return j;
    }

    /**
     * Primary JNDI name.
     * 
     * @return the jndi property holder
     */
    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.primary")
    public JndiPropertyHolder primaryJNDIName() {
        return new JndiPropertyHolder();
    }

    /**
     * Primary data source.
     * 
     * @return the data source
     */
    @Bean(name = "primaryDS")
    @Primary
    public DataSource primaryDataSource() {
        JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
        DataSource dataSource = dataSourceLookup
                .getDataSource(primaryJNDIName().getJndiName());
        return dataSource;
    }

    /**
     * Secondary JNDI name.
     * 
     * @return the jndi property holder
     */
    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.secondary")
    public JndiPropertyHolder secondaryJNDIName() {
        return new JndiPropertyHolder();
    }

    /**
     * Secondary data source.
     * 
     * @return the data source
     */
    @Bean(name = "secondaryDS")
    public DataSource secondaryDataSource() {
        JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
        DataSource dataSource = dataSourceLookup
                .getDataSource(secondaryJNDIName().getJndiName());
        return dataSource;
    }

    /**
     * The Class JndiPropertyHolder.
     */
    private static class JndiPropertyHolder {
        /** The jndi name. */
        private String jndiName;

        /**
         * Gets the jndi name.
         * 
         * @return the jndi name
         */
        public String getJndiName() {
            return jndiName;
        }

        /**
         * Sets the jndi name.
         * 
         * @param jndiName
         *            the new jndi name
         */
        public void setJndiName(String jndiName) {
            this.jndiName = jndiName;
        }
    }
}
