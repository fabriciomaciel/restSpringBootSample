package br.com.brasilprev.bprextratodmlg.repository;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.brasilprev.bprextratodmlg.model.ora.RetornoProcedureORA;
import br.com.brasilprev.bprextratodmlg.model.ora.mapping.RetornoProcedureORARowMapper;

/**
 * The Class ExtratoOracleRepository.
 */
@Repository
public class ExtratoOracleRepository {
    /** The ora jdbc template. */
    @Autowired
    @Qualifier("jdbcSecondary")
    JdbcTemplate oraJdbcTemplate;
    /** The date format. */
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * Gets the query.
     * 
     * @param matricula
     *            the matricula
     * @param data
     *            the data
     * @return the query
     */
    private String getQuery(Long matricula, Date data) {
        String q1 = "SELECT ID_INVESTIMENTO, VALORCOTA, QUANTIDADECOTASTOTAL, CASE WHEN SALDOATUAPROV < 0 THEN 0 ELSE SALDOATUAPROV END SALDOATUAPROV FROM (SELECT NVL(MIV.ID_INV, -1) AS ID_INVESTIMENTO, COT.VL_COT AS VALORCOTA, SUM(CASE WHEN TRN.IC_TRN_DBT_CRD = 'C' THEN NVL(MIV.QT_COT_APA_INV, 0) ELSE -NVL(MIV.QT_COT_APA_INV, 0) END)  AS QUANTIDADECOTASTOTAL, CASE WHEN MAX(MIV.ID_MOV_BID) IS NULL THEN SUM(CASE WHEN TRN.IC_TRN_DBT_CRD = 'C' THEN CASE WHEN CTB.CD_CTU_PRA = 'N' THEN MOV.VL_MOV_RSV_LIQ ELSE MOV.VL_MOV_RSV_BRT END ELSE CASE WHEN CTB.CD_CTU_PRA = 'N' THEN -MOV.VL_MOV_RSV_BRT ELSE -MOV.VL_MOV_RSV_LIQ END END) ELSE ROUND(SUM(CASE WHEN TRN.IC_TRN_DBT_CRD = 'C' THEN MIV.QT_COT_APA_INV ELSE -MIV.QT_COT_APA_INV END) * COT.VL_COT,2) END AS SALDOATUAPROV FROM BID.BIDVGMOV MOV LEFT JOIN BID.BIDVGMOV_INV MIV ON MIV.ID_MOV_BID = MOV.ID_MOV_BID INNER JOIN BID.BIDDOMTRN    TRN ON TRN.ID_TRN = MOV.ID_TRN LEFT JOIN (SELECT INC.ID_INV, INC.VL_COT, INC.DT_CTC FROM BID.BIDVGINV_CTC INC WHERE INC.DT_CTC = (SELECT MAX(X.DT_CTC)FROM BID.BIDVGINV_CTC X WHERE X.DT_CTC <= to_date('"
                + dateFormat.format(data)
                + "','yyyy-mm-dd') AND X.ID_INV = INC.ID_INV)) COT ON MIV.ID_INV = COT.ID_INV INNER JOIN BID.BIDEQTBL_CPO_ASC_CTU CTC ON TRN.ID_TRN = CTC.CD_CTU_DE AND CTC.ID_TBL_CPO_ASC = 78 INNER JOIN BID.BIDEQTBL_CPO_ASC_CTU CTX ON MOV.ID_CTA_RSV = CTX.CD_CTU_DE AND CTX.ID_TBL_CPO_ASC = 71 INNER JOIN BID.BIDEQTBL_CPO_ASC_CTU CTB ON TRN.ID_TRN = CTB.CD_CTU_DE AND CTB.ID_TBL_CPO_ASC = 77 WHERE MOV.ID_RLC_CML_BID = "
                + matricula
                + " AND MOV.DT_MOV_RSV <= to_date('"
                + dateFormat.format(data)
                + "','yyyy-mm-dd') AND CTX.CD_CTU_PRA = 'N' AND MOV.VL_MOV_RSV_BRT <> 0 AND ((MOV.ID_BCR_TBL = 74 AND MOV.IC_RVS = 'N' AND CTC.CD_CTU_PRA = 'N') OR MOV.ID_BCR_TBL <> 74) GROUP BY MIV.ID_INV, COT.DT_CTC, COT.VL_COT)";
        return q1;
    }

    /**
     * Extrato.
     * 
     * @param data
     *            the data
     * @param matricula
     *            the matricula
     * @return the retorno procedure ORA
     */
    public RetornoProcedureORA extrato(Date data, Long matricula) {
        String queryStr = getQuery(matricula, data);
        return oraJdbcTemplate.queryForObject(queryStr,
                new RetornoProcedureORARowMapper());
    }
}
