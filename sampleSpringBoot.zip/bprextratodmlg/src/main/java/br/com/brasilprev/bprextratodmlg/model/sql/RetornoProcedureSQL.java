package br.com.brasilprev.bprextratodmlg.model.sql;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class RetornoProcedureSQL.
 */
@JsonFormat(shape = JsonFormat.Shape.STRING)
public class RetornoProcedureSQL {
    /** The money type nmbr. */
    @JsonProperty
    private String moneyTypeNmbr;
    /** The inv type nmbr. */
    @JsonProperty
    private String invTypeNmbr;
    /** The inv grp cd. */
    @JsonProperty
    private String invGrpCd;
    /** The unit cnt. */
    @JsonProperty
    private String unitCnt;
    /** The total amt. */
    @JsonProperty
    private String totalAmt;
    /** The nominal. */
    @JsonProperty
    private String nominal;
    /** The perc nominal. */
    @JsonProperty
    private String percNominal;
    /** The uni cnt N. */
    @JsonProperty
    private String unitCntN;
    /** The rendimento. */
    @JsonProperty
    private String rendimento;
    /** The perc rendimento. */
    @JsonProperty
    private String percRendimento;
    /** The unit cnt R. */
    @JsonProperty
    private String unitCntR;
    /** The vest total amt. */
    @JsonProperty
    private String vestTotalAmt;
    /** The vest unit cnt. */
    @JsonProperty
    private String vestUnitCnt;
    /** The vest nominal. */
    @JsonProperty
    private String vestNominal;
    /** The vest unit cnt N. */
    @JsonProperty
    private String vestUnitCntN;
    /** The vest rendimento. */
    @JsonProperty
    private String vestRendimento;
    /** The vest unit cnt R. */
    @JsonProperty
    private String vestUnitCntR;
    /** The trns dtl seq nmbr. */
    @JsonProperty
    private String trnsDtlSeqNmbr;
    /** The money dt. */
    @JsonProperty
    private String moneyDt;
    /** The wdrl available dt. */
    @JsonProperty
    private String wdrlAvailableDt;
    /** The origpaid dt. */
    @JsonProperty
    private String origPaidDt;
    /** The tg id grupo fundo. */
    @JsonProperty
    private String tgIdGrupoFundo;
    /** The tg id fundo. */
    @JsonProperty
    private String tgIdFundo;
    /** The tg ft aliquota. */
    @JsonProperty
    private String tgFtAliquota;
    /** The tg id faixa forma tributacao. */
    @JsonProperty
    private String tgIdFaixaFormaTributacao;
    /** The tg id custeio. */
    @JsonProperty
    private String tgIdCusteio;
    /** The unit price amt. */
    @JsonProperty
    private String unitPriceAmt;

    /**
     * Gets the money type nmbr.
     * 
     * @return the moneyTypeNmbr
     */
    public String getMoneyTypeNmbr() {
        return moneyTypeNmbr;
    }

    /**
     * Sets the money type nmbr.
     * 
     * @param moneyTypeNmbr
     *            the moneyTypeNmbr to set
     */
    public void setMoneyTypeNmbr(String moneyTypeNmbr) {
        this.moneyTypeNmbr = moneyTypeNmbr;
    }

    /**
     * Gets the inv type nmbr.
     * 
     * @return the invTypeNmbr
     */
    public String getInvTypeNmbr() {
        return invTypeNmbr;
    }

    /**
     * Sets the inv type nmbr.
     * 
     * @param invTypeNmbr
     *            the invTypeNmbr to set
     */
    public void setInvTypeNmbr(String invTypeNmbr) {
        this.invTypeNmbr = invTypeNmbr;
    }

    /**
     * Gets the inv grp cd.
     * 
     * @return the invGrpCd
     */
    public String getInvGrpCd() {
        return invGrpCd;
    }

    /**
     * Sets the inv grp cd.
     * 
     * @param invGrpCd
     *            the invGrpCd to set
     */
    public void setInvGrpCd(String invGrpCd) {
        this.invGrpCd = invGrpCd;
    }

    /**
     * Gets the unit cnt.
     * 
     * @return the unitCnt
     */
    public String getUnitCnt() {
        return unitCnt;
    }

    /**
     * Sets the unit cnt.
     * 
     * @param unitCnt
     *            the unitCnt to set
     */
    public void setUnitCnt(String unitCnt) {
        this.unitCnt = unitCnt;
    }

    /**
     * Gets the total amt.
     * 
     * @return the totalAmt
     */
    public String getTotalAmt() {
        return totalAmt;
    }

    /**
     * Sets the total amt.
     * 
     * @param totalAmt
     *            the totalAmt to set
     */
    public void setTotalAmt(String totalAmt) {
        this.totalAmt = totalAmt;
    }

    /**
     * Gets the nominal.
     * 
     * @return the nominal
     */
    public String getNominal() {
        return nominal;
    }

    /**
     * Sets the nominal.
     * 
     * @param nominal
     *            the nominal to set
     */
    public void setNominal(String nominal) {
        this.nominal = nominal;
    }

    /**
     * Gets the perc nominal.
     * 
     * @return the percNominal
     */
    public String getPercNominal() {
        return percNominal;
    }

    /**
     * Sets the perc nominal.
     * 
     * @param percNominal
     *            the percNominal to set
     */
    public void setPercNominal(String percNominal) {
        this.percNominal = percNominal;
    }

    /**
     * Gets the unit cnt N.
     * 
     * @return the unitCntN
     */
    public String getUnitCntN() {
        return unitCntN;
    }

    /**
     * Sets the unit cnt N.
     * 
     * @param unitCntN
     *            the unitCntN to set
     */
    public void setUnitCntN(String unitCntN) {
        this.unitCntN = unitCntN;
    }

    /**
     * Gets the rendimento.
     * 
     * @return the rendimento
     */
    public String getRendimento() {
        return rendimento;
    }

    /**
     * Sets the rendimento.
     * 
     * @param rendimento
     *            the rendimento to set
     */
    public void setRendimento(String rendimento) {
        this.rendimento = rendimento;
    }

    /**
     * Gets the perc rendimento.
     * 
     * @return the percRendimento
     */
    public String getPercRendimento() {
        return percRendimento;
    }

    /**
     * Sets the perc rendimento.
     * 
     * @param percRendimento
     *            the percRendimento to set
     */
    public void setPercRendimento(String percRendimento) {
        this.percRendimento = percRendimento;
    }

    /**
     * Gets the unit cnt R.
     * 
     * @return the unitCntR
     */
    public String getUnitCntR() {
        return unitCntR;
    }

    /**
     * Sets the unit cnt R.
     * 
     * @param unitCntR
     *            the unitCntR to set
     */
    public void setUnitCntR(String unitCntR) {
        this.unitCntR = unitCntR;
    }

    /**
     * Gets the vest total amt.
     * 
     * @return the vestTotalAmt
     */
    public String getVestTotalAmt() {
        return vestTotalAmt;
    }

    /**
     * Sets the vest total amt.
     * 
     * @param vestTotalAmt
     *            the vestTotalAmt to set
     */
    public void setVestTotalAmt(String vestTotalAmt) {
        this.vestTotalAmt = vestTotalAmt;
    }

    /**
     * Gets the vest unit cnt.
     * 
     * @return the vestUnitCnt
     */
    public String getVestUnitCnt() {
        return vestUnitCnt;
    }

    /**
     * Sets the vest unit cnt.
     * 
     * @param vestUnitCnt
     *            the vestUnitCnt to set
     */
    public void setVestUnitCnt(String vestUnitCnt) {
        this.vestUnitCnt = vestUnitCnt;
    }

    /**
     * Gets the vest nominal.
     * 
     * @return the vestNominal
     */
    public String getVestNominal() {
        return vestNominal;
    }

    /**
     * Sets the vest nominal.
     * 
     * @param vestNominal
     *            the vestNominal to set
     */
    public void setVestNominal(String vestNominal) {
        this.vestNominal = vestNominal;
    }

    /**
     * Gets the vest unit cnt N.
     * 
     * @return the vestUnitCntN
     */
    public String getVestUnitCntN() {
        return vestUnitCntN;
    }

    /**
     * Sets the vest unit cnt N.
     * 
     * @param vestUnitCntN
     *            the vestUnitCntN to set
     */
    public void setVestUnitCntN(String vestUnitCntN) {
        this.vestUnitCntN = vestUnitCntN;
    }

    /**
     * Gets the vest rendimento.
     * 
     * @return the vestRendimento
     */
    public String getVestRendimento() {
        return vestRendimento;
    }

    /**
     * Sets the vest rendimento.
     * 
     * @param vestRendimento
     *            the vestRendimento to set
     */
    public void setVestRendimento(String vestRendimento) {
        this.vestRendimento = vestRendimento;
    }

    /**
     * Gets the vest unit cnt R.
     * 
     * @return the vestUnitCntR
     */
    public String getVestUnitCntR() {
        return vestUnitCntR;
    }

    /**
     * Sets the vest unit cnt R.
     * 
     * @param vestUnitCntR
     *            the vestUnitCntR to set
     */
    public void setVestUnitCntR(String vestUnitCntR) {
        this.vestUnitCntR = vestUnitCntR;
    }

    /**
     * Gets the trns dtl seq nmbr.
     * 
     * @return the trnsDtlSeqNmbr
     */
    public String getTrnsDtlSeqNmbr() {
        return trnsDtlSeqNmbr;
    }

    /**
     * Sets the trns dtl seq nmbr.
     * 
     * @param trnsDtlSeqNmbr
     *            the trnsDtlSeqNmbr to set
     */
    public void setTrnsDtlSeqNmbr(String trnsDtlSeqNmbr) {
        this.trnsDtlSeqNmbr = trnsDtlSeqNmbr;
    }

    /**
     * Gets the money dt.
     * 
     * @return the moneyDt
     */
    public String getMoneyDt() {
        return moneyDt;
    }

    /**
     * Sets the money dt.
     * 
     * @param moneyDt
     *            the moneyDt to set
     */
    public void setMoneyDt(String moneyDt) {
        this.moneyDt = moneyDt;
    }

    /**
     * Gets the wdrl available dt.
     * 
     * @return the wdrlAvailableDt
     */
    public String getWdrlAvailableDt() {
        return wdrlAvailableDt;
    }

    /**
     * Sets the wdrl available dt.
     * 
     * @param wdrlAvailableDt
     *            the wdrlAvailableDt to set
     */
    public void setWdrlAvailableDt(String wdrlAvailableDt) {
        this.wdrlAvailableDt = wdrlAvailableDt;
    }

    /**
     * Gets the origpaid dt.
     * 
     * @return the origPaidDt
     */
    public String getOrigPaidDt() {
        return origPaidDt;
    }

    /**
     * Sets the origPaidDt dt.
     * 
     * @param origPaidDt
     *            the origPaidDt to set
     */
    public void setOrigPaidDt(String origPaidDt) {
        this.origPaidDt = origPaidDt;
    }

    /**
     * Gets the tg id grupo fundo.
     * 
     * @return the tgIdGrupoFundo
     */
    public String getTgIdGrupoFundo() {
        return tgIdGrupoFundo;
    }

    /**
     * Sets the tg id grupo fundo.
     * 
     * @param tgIdGrupoFundo
     *            the tgIdGrupoFundo to set
     */
    public void setTgIdGrupoFundo(String tgIdGrupoFundo) {
        this.tgIdGrupoFundo = tgIdGrupoFundo;
    }

    /**
     * Gets the tg id fundo.
     * 
     * @return the tgIdFundo
     */
    public String getTgIdFundo() {
        return tgIdFundo;
    }

    /**
     * Sets the tg id fundo.
     * 
     * @param tgIdFundo
     *            the tgIdFundo to set
     */
    public void setTgIdFundo(String tgIdFundo) {
        this.tgIdFundo = tgIdFundo;
    }

    /**
     * Gets the tg ft aliquota.
     * 
     * @return the tgFtAliquota
     */
    public String getTgFtAliquota() {
        return tgFtAliquota;
    }

    /**
     * Sets the tg ft aliquota.
     * 
     * @param tgFtAliquota
     *            the tgFtAliquota to set
     */
    public void setTgFtAliquota(String tgFtAliquota) {
        this.tgFtAliquota = tgFtAliquota;
    }

    /**
     * Gets the tg id faixa forma tributacao.
     * 
     * @return the tgIdFaixaFormaTributacao
     */
    public String getTgIdFaixaFormaTributacao() {
        return tgIdFaixaFormaTributacao;
    }

    /**
     * Sets the tg id faixa forma tributacao.
     * 
     * @param tgIdFaixaFormaTributacao
     *            the tgIdFaixaFormaTributacao to set
     */
    public void setTgIdFaixaFormaTributacao(String tgIdFaixaFormaTributacao) {
        this.tgIdFaixaFormaTributacao = tgIdFaixaFormaTributacao;
    }

    /**
     * Gets the tg id custeio.
     * 
     * @return the tgIdCusteio
     */
    public String getTgIdCusteio() {
        return tgIdCusteio;
    }

    /**
     * Sets the tg id custeio.
     * 
     * @param tgIdCusteio
     *            the tgIdCusteio to set
     */
    public void setTgIdCusteio(String tgIdCusteio) {
        this.tgIdCusteio = tgIdCusteio;
    }

    /**
     * Gets the unit price amt.
     * 
     * @return the unitPriceAmt
     */
    public String getUnitPriceAmt() {
        return unitPriceAmt;
    }

    /**
     * Sets the unit price amt.
     * 
     * @param unitPriceAmt
     *            the unitPriceAmt to set
     */
    public void setUnitPriceAmt(String unitPriceAmt) {
        this.unitPriceAmt = unitPriceAmt;
    }
}
