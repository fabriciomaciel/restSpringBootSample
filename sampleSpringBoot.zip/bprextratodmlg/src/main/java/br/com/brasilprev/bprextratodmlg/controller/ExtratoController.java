package br.com.brasilprev.bprextratodmlg.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.brasilprev.bprextratodmlg.model.ora.RetornoProcedureORA;
import br.com.brasilprev.bprextratodmlg.model.sql.RetornoProcedureSQL;
import br.com.brasilprev.bprextratodmlg.repository.ExtratoOracleRepository;
import br.com.brasilprev.bprextratodmlg.repository.ExtratoSqlServerRepository;

/**
 * The Class ExtratoController.
 */
@RestController
@RequestMapping("api/v1")
public class ExtratoController {

    /** The sql repository. */
    @Autowired
    ExtratoSqlServerRepository sqlRepository;

    /** The ora repository. */
    @Autowired
    ExtratoOracleRepository oraRepository;

    /**
     * Status.
     * 
     * @return the string
     */
    @GetMapping("/status")
    public String status() {
        return "online";
    }

    /**
     * Extratosql.
     * 
     * @param matricula
     *            the matricula
     * @param data
     *            the data
     * @return the list
     * @throws ParseException
     *             the parse exception
     */
    @GetMapping("/extratosql/{matricula}/{data}")
    public @ResponseBody
    List<RetornoProcedureSQL> extratosql(@PathVariable("matricula") Long matricula, @PathVariable("data") String data)
            throws ParseException {
        DateFormat df = new SimpleDateFormat("ddMMyyyy");
        return sqlRepository.extrato(df.parse(data), matricula);
    }

    /**
     * Extratoora.
     * 
     * @param matricula
     *            the matricula
     * @param data
     *            the data
     * @return the retorno procedure ORA
     * @throws ParseException
     *             the parse exception
     */
    @GetMapping("/extratoora/{matricula}/{data}")
    public @ResponseBody
    RetornoProcedureORA extratoora(@PathVariable("matricula") Long matricula, @PathVariable("data") String data)
            throws ParseException {
        DateFormat df = new SimpleDateFormat("ddMMyyyy");
        return oraRepository.extrato(df.parse(data), matricula);
    }
}