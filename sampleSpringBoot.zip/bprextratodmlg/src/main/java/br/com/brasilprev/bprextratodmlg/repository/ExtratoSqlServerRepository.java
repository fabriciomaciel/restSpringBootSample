package br.com.brasilprev.bprextratodmlg.repository;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import br.com.brasilprev.bprextratodmlg.model.sql.RetornoProcedureSQL;
import br.com.brasilprev.bprextratodmlg.model.sql.mapping.RetornoProcedureSQLRowMapper;

/**
 * The Class ExtratoSqlServerRepository.
 */
@Repository
public class ExtratoSqlServerRepository {
    /** The sql jdbc template. */
    @Autowired
    @Qualifier("jdbcPrimary")
    JdbcTemplate sqlJdbcTemplate;
    /** The date format. */
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * Extrato.
     * 
     * @param dataPesquisa
     *            the data pesquisa
     * @param matricula
     *            the matricula
     * @return the list
     */
    public List<RetornoProcedureSQL> extrato(Date dataPesquisa, Long matricula) {
        String queryString = "DECLARE @MATRICULA BIGINT ,@P_EFCTV_DT DATETIME ,@P_CLNT_RLTNSHP_NMBR INT ,@P_MONEY_TYPE_NMBR SMALLINT= NULL,@P_MONEY_SOURCE_NMBR SMALLINT= NULL ,@P_INV_TYPE_NMBR SMALLINT= NULL ,@P_SLD_DISP_FLG CHAR(1) = '1' ,@P_VESTING_FLG CHAR(1)='1' ,@P_DETALHE_FLG CHAR(1)='1' ,@P_VL_DETALHE_FLG CHAR(1)='1' ,@P_WARNING_FLG CHAR(1) = '1',@P_FAIXA_TRIB_FLG CHAR(1) = '1',@P_COMPENSAR_N_R  CHAR(1) = '1',@P_SALDO_BUC_FLG  CHAR(1) = '1',@FIRED_EMPLOYEE_ID INT = 3,@FIRED_EMPLOYEE_DT DATETIME= NULL,@VRFY_VEST_FLG CHAR(1) = 'S',@FLG_RESGATE_MIGRACAO CHAR(1) = 'R',@FLG_QUERY_ACCOUNT CHAR(1) = 'N',@FLG_TRNS_FUNDOS CHAR(1) = 'N',@FLG_RESGATE CHAR(1) = 'N',@RET INT; SELECT @MATRICULA = CLNT_RLTNSHP_NMBR FROM life WHERE external_policy_id = "
                + matricula
                + "; SET  @P_EFCTV_DT = '"
                + dateFormat.format(dataPesquisa)
                + "'; SET @P_CLNT_RLTNSHP_NMBR = @MATRICULA EXEC sp_obter_saldo @P_EFCTV_DT,@P_CLNT_RLTNSHP_NMBR SELECT @RET";
        return sqlJdbcTemplate.query(queryString,
                new RetornoProcedureSQLRowMapper());
    }
}