package br.com.brasilprev.bprextratodmlg.model.sql.mapping;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.com.brasilprev.bprextratodmlg.model.sql.RetornoProcedureSQL;

/**
 * The Class RetornoProcedureSQLRowMapper.
 */
public class RetornoProcedureSQLRowMapper implements
        RowMapper<RetornoProcedureSQL> {
    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet,
     * int)
     */
    @Override
    public RetornoProcedureSQL mapRow(ResultSet rs, int rowNum)
            throws SQLException {
        RetornoProcedureSQL r = new RetornoProcedureSQL();
        r.setInvGrpCd(rs.getString("INV_GRP_CD"));
        r.setInvTypeNmbr(rs.getString("INV_TYPE_NMBR"));
        r.setMoneyDt(rs.getString("MONEY_DT"));
        r.setMoneyTypeNmbr(rs.getString("MONEY_TYPE_NMBR"));
        r.setNominal(rs.getString("NOMINAL"));
        r.setOrigPaidDt(rs.getString("ORIG_PAID_DT"));
        r.setPercNominal(rs.getString("PERC_NOMINAL"));
        r.setPercRendimento(rs.getString("PERC_RENDIMENTO"));
        r.setRendimento(rs.getString("RENDIMENTO"));
        r.setTgFtAliquota(rs.getString("TG_FT_ALIQUOTA"));
        r.setTgIdCusteio(rs.getString("TG_ID_CUSTEIO"));
        r.setTgIdFaixaFormaTributacao(rs
                .getString("TG_ID_FAIXA_FORMA_TRIBUTACAO"));
        r.setTgIdFundo(rs.getString("TG_ID_FUNDO"));
        r.setTgIdGrupoFundo(rs.getString("TG_ID_GRUPO_FUNDO"));
        r.setTotalAmt(rs.getString("TOTAL_AMT"));
        r.setTrnsDtlSeqNmbr(rs.getString("TRNS_DTL_SEQ_NMBR"));
        r.setUnitCnt(rs.getString("UNIT_CNT"));
        r.setUnitCntN(rs.getString("UNIT_CNT_N"));
        r.setUnitCntR(rs.getString("UNIT_CNT_R"));
        r.setUnitPriceAmt(rs.getString("UNIT_PRICE_AMT"));
        r.setVestNominal(rs.getString("VEST_NOMINAL"));
        r.setVestRendimento(rs.getString("VEST_RENDIMENTO"));
        r.setVestTotalAmt(rs.getString("VEST_TOTAL_AMT"));
        r.setVestUnitCnt(rs.getString("VEST_UNIT_CNT"));
        r.setVestUnitCntN(rs.getString("VEST_UNIT_CNT_N"));
        r.setVestUnitCntR(rs.getString("VEST_UNIT_CNT_R"));
        r.setWdrlAvailableDt(rs.getString("WDRL_AVAILABLE_DT"));
        return r;
    }
}
