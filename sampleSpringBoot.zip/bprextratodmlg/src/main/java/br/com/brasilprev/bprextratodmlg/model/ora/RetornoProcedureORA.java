package br.com.brasilprev.bprextratodmlg.model.ora;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The Class RetornoProcedureORA.
 */
@JsonFormat(shape = JsonFormat.Shape.STRING)
public class RetornoProcedureORA {

    /** The id INVESTIMENTO. */
    @JsonProperty
    private String idInvestimento;

    /** The valorcota. */
    @JsonProperty
    private String valorCota;

    /** The quantidadecotastotal. */
    @JsonProperty
    private String quantidadeCotasTotal;

    /** The saldoatuaprov. */
    @JsonProperty
    private String saldoAtuaProv;

    /**
     * @return the idInvestimento
     */
    public String getIdInvestimento() {
        return idInvestimento;
    }

    /**
     * @param idInvestimento
     *            the idInvestimento to set
     */
    public void setIdInvestimento(String idInvestimento) {
        this.idInvestimento = idInvestimento;
    }

    /**
     * @return the valorCota
     */
    public String getValorCota() {
        return valorCota;
    }

    /**
     * @param valorCota
     *            the valorCota to set
     */
    public void setValorCota(String valorCota) {
        this.valorCota = valorCota;
    }

    /**
     * @return the quantidadeCotasTotal
     */
    public String getQuantidadeCotasTotal() {
        return quantidadeCotasTotal;
    }

    /**
     * @param quantidadeCotasTotal
     *            the quantidadeCotasTotal to set
     */
    public void setQuantidadeCotasTotal(String quantidadeCotasTotal) {
        this.quantidadeCotasTotal = quantidadeCotasTotal;
    }

    /**
     * @return the saldoAtuaProv
     */
    public String getSaldoAtuaProv() {
        return saldoAtuaProv;
    }

    /**
     * @param saldoAtuaProv
     *            the saldoAtuaProv to set
     */
    public void setSaldoAtuaProv(String saldoAtuaProv) {
        this.saldoAtuaProv = saldoAtuaProv;
    }

}