package br.com.brasilprev.bprextratodmlg.model.ora.mapping;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import br.com.brasilprev.bprextratodmlg.model.ora.RetornoProcedureORA;

/**
 * The Class RetornoProcedureORARowMapper.
 */
public class RetornoProcedureORARowMapper implements RowMapper<RetornoProcedureORA> {

    /*
     * (non-Javadoc)
     * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet,
     * int)
     */
    @Override
    public RetornoProcedureORA mapRow(ResultSet rs, int rowNum) throws SQLException {
        RetornoProcedureORA r = new RetornoProcedureORA();
        r.setIdInvestimento(rs.getString("ID_INVESTIMENTO"));
        r.setQuantidadeCotasTotal(rs.getString("QUANTIDADECOTASTOTAL"));
        r.setSaldoAtuaProv(rs.getString("SALDOATUAPROV"));
        r.setValorCota(rs.getString("VALORCOTA"));
        return r;
    }
}